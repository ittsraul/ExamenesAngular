export interface PhotosContent {
    image: string[];
    text: string;
    clase: string;
}
